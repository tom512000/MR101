# view/__init__.py

import pygame

# Initialisation de PyGame
pygame.init()
